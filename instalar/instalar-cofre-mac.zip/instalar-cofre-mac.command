#!/bin/bash
# Cofre de Anonimizacao para Word: instalacao no Mac
# Ana Marta Soares, Especialista em IA aplicada ao Direito
clear
echo ""
echo "  Cofre de Anonimização para Word"
echo "  A instalar..."
echo ""
osascript -e 'tell application "Microsoft Word" to quit' >/dev/null 2>&1
DIR="$HOME/Library/Containers/com.microsoft.Word/Data/Documents/wef"
mkdir -p "$DIR"
if curl -fsSL "https://ana-marta-soares-direito-ia.github.io/cofre-anonimizacao-word/manifest.xml" -o "$DIR/cofre-anonimizacao.xml"; then
  echo "  Instalação concluída."
  echo ""
  echo "  Abra o Word e um documento. No separador Base, seleccione Suplementos"
  echo "  e escolha Cofre de Anonimização. Depois, cole o seu código de licença."
  osascript -e 'display dialog "Instalação concluída.\n\nAbra o Word e um documento. No separador Base, seleccione Suplementos e escolha Cofre de Anonimização." with title "Cofre de Anonimização" buttons {"OK"} default button "OK"' >/dev/null 2>&1
else
  echo "  Não foi possível descarregar o suplemento. Verifique a ligação à Internet e tente novamente."
fi
echo ""
echo "  Pode fechar esta janela."
